﻿using RecetasSLN.Servicios.Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//114032 - Báez Nicolás

namespace RecetasSLN.presentación
{
    public partial class FrmPrincipal : Form
    {
        private IFabricaServicios lFabrica;
        public FrmPrincipal(IFabricaServicios fabrica)
        {
            InitializeComponent();
            this.lFabrica = fabrica;
        }

        private void pedidosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmConsultar lConsultarPedidos = new FrmConsultar(lFabrica);
            lConsultarPedidos.ShowDialog();
        }

        private void FrmPrincipal_Load(object sender, EventArgs e)
        {

        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Desea salir de la app?", "QUESTION", MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                this.Close();
            }
        }
    }
}
