﻿using RecetasSLN.Datos.Implementaciones;
using RecetasSLN.dominio;
using RecetasSLN.dominio.SP;
using RecetasSLN.Servicios.Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//114032 - Báez Nicolás

namespace RecetasSLN.presentación
{
    public partial class FrmConsultar : Form
    {
        IServicios oServicio;
        SPSINPARAMETROS oSinParametros;

        int nro = 0;

        public FrmConsultar(IFabricaServicios lFabrica)
        {
            InitializeComponent();

            oServicio = lFabrica.CrearNuevoServicio();
            oSinParametros  = new SPSINPARAMETROS();
        }

        private void FrmConsultar_Load(object sender, EventArgs e)
        {
            dtpDesde.Value = Convert.ToDateTime("01/01/2000");
            dtpHasta.Value = DateTime.Now;
            CargarCombo();
        }

        private void CargarCombo()
        {
            List<Cliente> lstClientes = new List<Cliente>();
            Cliente ComboBoxCliente = new Cliente();

            ComboBoxCliente.Id = -2;
            ComboBoxCliente.NombreYApellido = "Todos los Clientes";
            lstClientes.Add(ComboBoxCliente);

            foreach (Cliente lCliente in oServicio.TraerClientes())
            {
                lstClientes.Add(lCliente);
            }

            cboClientes.DataSource = lstClientes;
            cboClientes.DisplayMember = "NombreYApellido";
            cboClientes.ValueMember = "Id";
        }

        private bool ValidarFlag()
        {
            bool Flag = false;

            if (cboClientes.SelectedIndex == 0)
            {
                Flag = true;
            }

            return Flag;
        }

        private void GetConsultarDgv(int id)
        {
            this.nro = 0;
            dgvPedidos.Rows.Clear();

            if (ValidarFlag() is true)
            {
                List<SPSINPARAMETROS> lstPedidos = oServicio.TraerPedidosSinFiltros(dtpDesde.Value, dtpHasta.Value);

                foreach (SPSINPARAMETROS lConsulta in lstPedidos)
                {
                    this.nro = this.nro + 1;
                    dgvPedidos.Rows.Add(new object[] {lConsulta.codigo, lConsulta.cliente,
                    lConsulta.fec_entrega, lConsulta.entregado, lConsulta.fecha_baja});
                }
            }
            else
            {
                List<SPCONSULTARPEDIDOS> lstPedidos = oServicio.TraerPedidosSQL(id, dtpDesde.Value, dtpHasta.Value);

                foreach (SPCONSULTARPEDIDOS lConsulta in lstPedidos)
                {
                    this.nro = this.nro + 1;
                    dgvPedidos.Rows.Add(new object[] {lConsulta.codigo, lConsulta.cliente,
                    lConsulta.fec_entrega, lConsulta.entregado, lConsulta.fecha_baja});
                }
            }
      
        }

        private void btnConsultar_Click(object sender, EventArgs e)
        {
            int ID = Convert.ToInt32(cboClientes.SelectedValue);
            GetConsultarDgv(ID);

            lblTotal.Text = "Total de pedidos: " + Convert.ToInt32(this.nro);
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Desea salir del pedido?", "QUESTION", MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                this.Dispose();
            }
        }

        private bool ValidacionEntrega()
        {
            bool resultado = true;

            if (dgvPedidos.CurrentRow.Cells["colEntregado"].Value.ToString() == "S")
            {
                MessageBox.Show("Error, el pedido ya fue entregado anteriormente..", "ERROR", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                resultado = false;
            }

            return resultado;
        }

        private bool ValidacionBaja()
        {
            bool resultado = true;

            if (dgvPedidos.CurrentRow.Cells["colEntregado"].Value.ToString() == "N")
            {
                MessageBox.Show("Error, el pedido ya fue dado de baja anteriormente..", "ERROR", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                resultado = false;
            }

            return resultado;
        }

        private void dgvPedidos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvPedidos.CurrentCell.ColumnIndex == 4)
            {
                if (ValidacionEntrega() is true)
                {
                    MessageBox.Show("El pedido fue entregado con éxito!", "INFO", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                    int Codigo = int.Parse(dgvPedidos.CurrentRow.Cells["colCodigo"].Value.ToString());
                    oServicio.TraerEntregarPedido(Codigo);
                    this.Dispose();
                }
            }

           else if (dgvPedidos.CurrentCell.ColumnIndex == 5)
            {
                if (ValidacionBaja() is true)
                {
                    MessageBox.Show("El pedido fue dado de baja exitosamente!", "INFO", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                    int Codigo = int.Parse(dgvPedidos.CurrentRow.Cells["colCodigo"].Value.ToString());
                    oServicio.TraerRegistraBaja(Codigo);
                    this.Dispose();
                }
                
            }

        }

        private void lblTotal_Click(object sender, EventArgs e)
        {
            
        }
    }
}
