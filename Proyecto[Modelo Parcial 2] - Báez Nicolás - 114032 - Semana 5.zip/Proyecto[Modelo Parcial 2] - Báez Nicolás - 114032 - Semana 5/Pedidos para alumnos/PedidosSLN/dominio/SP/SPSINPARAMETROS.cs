﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//114032 - Báez Nicolás

namespace RecetasSLN.dominio.SP
{
    public class SPSINPARAMETROS
    {
        public SPSINPARAMETROS(int codigo, DateTime fec_entrega, string dir_entrega, int id_cliente, string entregado, DateTime fecha_baja, string cliente)
        {
            this.codigo = codigo;
            this.fec_entrega = fec_entrega;
            this.dir_entrega = dir_entrega;
            this.id_cliente = id_cliente;
            this.entregado = entregado;
            this.fecha_baja = fecha_baja;
            this.cliente = cliente;
        }

        public SPSINPARAMETROS()
        {
            
        }

        public int codigo { get; set; }
        public DateTime fec_entrega { get; set; }
        public string dir_entrega { get; set; }
        public int id_cliente { get; set; }
        public string entregado { get; set; }
        public DateTime fecha_baja { get; set; }
        public string cliente { get; set; }
    }
}
