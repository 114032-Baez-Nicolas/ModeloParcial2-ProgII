﻿using RecetasSLN.Datos.Implementaciones;
using RecetasSLN.Datos.Interfaces;
using RecetasSLN.dominio;
using RecetasSLN.dominio.SP;
using RecetasSLN.Servicios.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//114032 - Báez Nicolás

namespace RecetasSLN.Servicios.Implementaciones
{
    public class Servicios : IServicios
    {
        private IPedidosDAO dao;

        public Servicios()
        {
            dao = new PedidosDAO();
        }

        public List<SPCONSULTARPEDIDOS> TraerPedidosSQL(int ID_CLIENTE, DateTime Fecha_Desde, DateTime Fecha_Hasta)
        {
            return dao.ObtenerPedidosSQL(ID_CLIENTE, Fecha_Desde, Fecha_Hasta);
        }

        public List<SPSINPARAMETROS> TraerPedidosSinFiltros(DateTime Fecha_Desde, DateTime Fecha_Hasta)
        {
            return dao.ObtenerPedidosSinFiltros(Fecha_Desde,Fecha_Hasta);
        }

        public List<Cliente> TraerClientes()
        {
            return dao.ObtenerClientes();
        }

        public bool TraerEntregarPedido(int Codigo)
        {
            return dao.ObtenerEntregarPedido(Codigo);
        }

        public bool TraerRegistraBaja(int Codigo)
        {
            return dao.ObtenerRegistraBaja(Codigo);
        }
    }
}
