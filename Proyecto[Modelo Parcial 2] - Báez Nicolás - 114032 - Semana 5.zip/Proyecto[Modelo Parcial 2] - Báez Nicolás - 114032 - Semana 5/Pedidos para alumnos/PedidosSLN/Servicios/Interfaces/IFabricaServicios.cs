﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//114032 - Báez Nicolás

namespace RecetasSLN.Servicios.Interfaces
{
    public interface IFabricaServicios
    {
        IServicios CrearNuevoServicio();
    }
}
