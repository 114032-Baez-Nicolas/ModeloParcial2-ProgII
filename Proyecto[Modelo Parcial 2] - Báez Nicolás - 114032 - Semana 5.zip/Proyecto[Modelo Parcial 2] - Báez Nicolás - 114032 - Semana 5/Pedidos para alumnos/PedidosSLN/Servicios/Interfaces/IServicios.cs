﻿using RecetasSLN.dominio.SP;
using RecetasSLN.dominio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//114032 - Báez Nicolás

namespace RecetasSLN.Servicios.Interfaces
{
    public interface IServicios
    {
        List<SPCONSULTARPEDIDOS> TraerPedidosSQL(int ID_CLIENTE, DateTime Fecha_Desde, DateTime Fecha_Hasta); //TRAE EL: Consultar
        List<Cliente> TraerClientes(); //TRAE EL: Obtener Combo Box Clientes
        List<SPSINPARAMETROS> TraerPedidosSinFiltros(DateTime Fecha_Desde, DateTime Fecha_Hasta); //Consultar (Solo Filtro de Busqueda)

        bool TraerEntregarPedido(int Codigo); //TRAE EL: SP (Registrar Entrega)
        bool TraerRegistraBaja(int Codigo); //TRAE EL: SP (Registrar Baja)
    }
}
