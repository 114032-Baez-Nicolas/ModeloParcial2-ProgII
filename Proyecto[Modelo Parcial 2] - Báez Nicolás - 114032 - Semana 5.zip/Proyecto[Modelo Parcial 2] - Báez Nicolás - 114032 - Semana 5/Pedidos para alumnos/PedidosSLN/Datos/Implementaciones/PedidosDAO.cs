﻿using RecetasSLN.Datos.AccesoDatos;
using RecetasSLN.Datos.Interfaces;
using RecetasSLN.dominio;
using RecetasSLN.dominio.SP;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//114032 - Báez Nicolás

namespace RecetasSLN.Datos.Implementaciones
{
    public class PedidosDAO : IPedidosDAO
    {

        //----------------CONSULTAR PEDIDOS (Con Filtros)-------------------
        public List<SPCONSULTARPEDIDOS> ObtenerPedidosSQL(int ID_CLIENTE, DateTime Fecha_Desde, DateTime Fecha_Hasta)
        {
            List<SPCONSULTARPEDIDOS> lstPedidos = new List<SPCONSULTARPEDIDOS>();

            List<Parametro> lstParametros = new List<Parametro>();
            lstParametros.Add(new Parametro("@cliente", ID_CLIENTE));
            lstParametros.Add(new Parametro("@fecha_desde", Fecha_Desde));
            lstParametros.Add(new Parametro("@fecha_hasta", Fecha_Hasta));

            DataTable lTabla = HelperDAO.ObtenerInstancia().ConsultaSQL("SP_CONSULTAR_PEDIDOS", lstParametros);
            foreach (DataRow lFila in lTabla.Rows)
            {
                SPCONSULTARPEDIDOS oPedidoSP = new SPCONSULTARPEDIDOS();

                oPedidoSP.codigo = Convert.ToInt32(lFila["codigo"]);
                oPedidoSP.fec_entrega = Convert.ToDateTime(lFila["fec_entrega"]);
                oPedidoSP.dir_entrega = lFila["dir_entrega"].ToString();
                oPedidoSP.id_cliente = Convert.ToInt32(lFila["id_cliente"]);
                oPedidoSP.entregado = lFila["entregado"].ToString();
                oPedidoSP.cliente = lFila["cliente"].ToString();

                if (lFila["fecha_baja"] != DBNull.Value)
                {
                    oPedidoSP.fecha_baja = Convert.ToDateTime(lFila["fecha_baja"]);
                }
                else
                {
                    oPedidoSP.fecha_baja = DateTime.MinValue;
                }

                lstPedidos.Add(oPedidoSP);
            }

            return lstPedidos;
        }

        //----------------CONSULTAR PEDIDOS (Solo filtro de tiempo)-------------------
        public List<SPSINPARAMETROS> ObtenerPedidosSinFiltros(DateTime Fecha_Desde, DateTime Fecha_Hasta)
        {
            List<SPSINPARAMETROS> lstPedidos = new List<SPSINPARAMETROS>();

            List<Parametro> lstParametros = new List<Parametro>();
            lstParametros.Add(new Parametro("@fecha_desde", Fecha_Desde));
            lstParametros.Add(new Parametro("@fecha_hasta", Fecha_Hasta));

            DataTable lTabla = HelperDAO.ObtenerInstancia().ConsultaSQL("SP_CONSULTAR_PEDIDOS_SOLOFILTROTIEMPO", lstParametros);
            foreach (DataRow lFila in lTabla.Rows)
            {
                SPSINPARAMETROS oPedidoSP = new SPSINPARAMETROS();

                oPedidoSP.codigo = Convert.ToInt32(lFila["codigo"]);
                oPedidoSP.fec_entrega = Convert.ToDateTime(lFila["fec_entrega"]);
                oPedidoSP.dir_entrega = lFila["dir_entrega"].ToString();
                oPedidoSP.id_cliente = Convert.ToInt32(lFila["id_cliente"]);
                oPedidoSP.entregado = lFila["entregado"].ToString();
                oPedidoSP.cliente = lFila["cliente"].ToString();

                if (lFila["fecha_baja"] != DBNull.Value)
                {
                    oPedidoSP.fecha_baja = Convert.ToDateTime(lFila["fecha_baja"]);
                }
                else
                {
                    oPedidoSP.fecha_baja = DateTime.MinValue;
                }

                lstPedidos.Add(oPedidoSP);
            }

            return lstPedidos;
        }

        //----------------OBTENER CLIENTE-------------------
        public List<Cliente> ObtenerClientes()
        {
            List<Cliente> lstClientes = new List<Cliente>();

            DataTable lTabla = HelperDAO.ObtenerInstancia().ComboBox("SP_CONSULTAR_CLIENTES");
            foreach (DataRow lFila in lTabla.Rows)
            {
                Cliente oCliente = new Cliente();

                oCliente.Id = Convert.ToInt32(lFila["id_cliente"]);
                oCliente.Nombre = lFila["nombre"].ToString();
                oCliente.Apellido = lFila["apellido"].ToString();
                oCliente.Dni = Convert.ToInt32(lFila["dni"]);
                oCliente.CodigoPostal = Convert.ToInt32(lFila["cod_postal"]);

                oCliente.NombreYApellido = $"{oCliente.Nombre} {oCliente.Apellido}";
                //oCliente.Pedidos = ObtenerPedidosSQL(oCliente.Id, fecDesde, fecHasta);

                lstClientes.Add(oCliente);
            }

            return lstClientes;
        }

        //----------------ENTREGA Y BAJA DE PEDIDOS-------------------
        public bool ObtenerEntregarPedido(int Codigo)
        {
            return HelperDAO.ObtenerInstancia().EntregarPedido(Codigo);
        }

        public bool ObtenerRegistraBaja(int Codigo)
        {
            return HelperDAO.ObtenerInstancia().RegistraBaja(Codigo);
        }




    }
}
