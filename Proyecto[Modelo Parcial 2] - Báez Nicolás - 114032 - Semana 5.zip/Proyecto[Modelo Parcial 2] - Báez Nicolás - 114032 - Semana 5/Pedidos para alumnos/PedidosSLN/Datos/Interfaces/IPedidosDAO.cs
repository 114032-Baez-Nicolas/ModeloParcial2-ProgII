﻿using RecetasSLN.dominio;
using RecetasSLN.dominio.SP;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//114032 - Báez Nicolás

namespace RecetasSLN.Datos.Interfaces
{
    public interface IPedidosDAO
    {
        List<SPCONSULTARPEDIDOS> ObtenerPedidosSQL(int ID_CLIENTE, DateTime Fecha_Desde, DateTime Fecha_Hasta); //Consultar (Con Filtros)
        List<SPSINPARAMETROS> ObtenerPedidosSinFiltros(DateTime Fecha_Desde, DateTime Fecha_Hasta); //Consultar (Solo filtro de Tiempo)
        List<Cliente> ObtenerClientes(); //Obtener Combo Box Clientes

        bool ObtenerEntregarPedido(int Codigo); //SP (Registrar Entrega)
        bool ObtenerRegistraBaja(int Codigo); //SP (Registrar Baja)
    }
}
