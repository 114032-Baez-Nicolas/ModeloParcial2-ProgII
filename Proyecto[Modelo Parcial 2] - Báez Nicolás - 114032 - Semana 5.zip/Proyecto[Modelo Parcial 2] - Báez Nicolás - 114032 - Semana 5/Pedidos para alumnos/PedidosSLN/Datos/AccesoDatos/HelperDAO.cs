﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
//114032 - Báez Nicolás

namespace RecetasSLN.Datos.AccesoDatos
{
    public class HelperDAO
    {
        SqlConnection lConexion;
        SqlCommand lComando = new SqlCommand();

        private static HelperDAO lInstancia;
        private HelperDAO()
        {
            lConexion = new SqlConnection(Properties.Resources.CandenaConexion);
        }

        public static HelperDAO ObtenerInstancia()
        {
            if (lInstancia == null)
            {
                lInstancia = new HelperDAO();
            }

            return lInstancia;
        }

        //-------------------- HERRAMIENTAS DE CONEXION --------------------
        private void ConectarSP()
        {
            lConexion.Open();
            lComando.Connection = lConexion;
            lComando.CommandType = CommandType.StoredProcedure;
        }

        private void Desconectar()
        {
            lConexion.Close();
        }

        //-------------------- ComboBox --------------------
        public DataTable ComboBox(string SPSQL)
        {

            DataTable lTabla = new DataTable();
            ConectarSP();

            lComando.Parameters.Clear();
            lComando.CommandText = SPSQL;

            lTabla.Load(lComando.ExecuteReader());
            Desconectar();

            return lTabla;
        }

        //-------------------- Entrega Pedido --------------------
        public bool EntregarPedido(int Codigo)
        {
            bool resultado;
            SqlTransaction lTransaction = null;
            try
            {
                //Transaction BEGIN
                ConectarSP();
                lComando.Parameters.Clear();

                lTransaction = lConexion.BeginTransaction();
                lComando.Transaction = lTransaction;
                lComando.CommandText = "SP_REGISTRAR_ENTREGA";
                //Transaction END

                lComando.Parameters.AddWithValue("@codigo", Codigo);
                lComando.ExecuteNonQuery();

                lTransaction.Commit();
                resultado = true;
            }
            catch (Exception)
            {
                lTransaction.Rollback();
                resultado = false;
            }
            finally
            {
                if (lConexion != null && lConexion.State == ConnectionState.Open)
                {
                    Desconectar();
                }
            }
            return resultado;
        }

        //-------------------- Registra Baja --------------------
        public bool RegistraBaja(int Codigo)
        {
            bool resultado;
            SqlTransaction lTransaction = null;
            try
            {
                //Transaction BEGIN
                ConectarSP();
                lComando.Parameters.Clear();

                lTransaction = lConexion.BeginTransaction();
                lComando.Transaction = lTransaction;
                lComando.CommandText = "SP_REGISTRAR_BAJA";
                //Transaction END

                lComando.Parameters.AddWithValue("@codigo", Codigo);
                lComando.ExecuteNonQuery();

                lTransaction.Commit();
                resultado = true;
            }
            catch (Exception)
            {
                lTransaction.Rollback();
                resultado = false;
            }
            finally
            {
                if (lConexion != null && lConexion.State == ConnectionState.Open)
                {
                    Desconectar();
                }
            }
            return resultado;
        }

        //-------------------- Consultar SQL --------------------
        public DataTable ConsultaSQL(string SPSQL, List<Parametro> lstParametros)
        {
            DataTable lTabla = new DataTable();
            ConectarSP();
            lComando.CommandText = SPSQL;
            lComando.Parameters.Clear();

            foreach (Parametro lParam in lstParametros)
            {
                lComando.Parameters.AddWithValue(lParam.Nombre, lParam.Valor);
            }

            lTabla.Load(lComando.ExecuteReader());
            Desconectar();

            return lTabla;
        }

    }
}
